package Resultpackage;

import Studentpackage.Register;
import Studentpackage.Subjectlist;

public class Results {
	
	Results()
	{
		Register obj=new Register();
		int u=1;
		System.out.println("Student name is"+obj.name);
		System.out.println("branch is "+obj.branch);
		for(int i=1;i<=4;i++)
		{
			System.out.println("semester "+i);
			for(int j=1;j<=obj.total.get(j);j++)
			{
				Subjectlist x=obj.sems.get(u);
				u++;
				System.out.println("Subject\n"+j+"Credits\n"+x.c+"Grades"+x.g);
				
				
			}
			System.out.println("SGPA of semester:"+i+" is"+obj.sgpa.get(i));
		}
		System.out.println("CGPA"+obj.totalcgpa/4);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Results object=new Results();

	}

}
