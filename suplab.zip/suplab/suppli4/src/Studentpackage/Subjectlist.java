package Studentpackage;

public class Subjectlist {
	public int c,g;
	public Subjectlist(int credits,int grades)
	{
		this.c=credits;
		this.g=grades;
	}

}
