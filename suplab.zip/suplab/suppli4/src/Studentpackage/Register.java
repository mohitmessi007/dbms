package Studentpackage;

import java.util.*;

interface student{
	 void getdata();
}

public class Register implements student {
	
	public HashMap<Integer,Integer>total=new HashMap();
	public HashMap<Integer,Double>sgpa=new HashMap();
	public HashMap<Integer,Subjectlist>sems=new HashMap();
	Scanner in=new Scanner(System.in);
	public String name,branch;
	public double totalcgpa=0.0;
	Subjectlist obj;
	public Register()
	{
		getdata();
	}
	public void getdata()
	{
		System.out.println("enter name");
		name=in.next();
		System.out.println("enter branch");
		branch=in.next();
		int u=1;
		for(int i=1;i<=4;i++)
		{
			int tg,cg,tcg;
			tg=cg=tcg=0;
			System.out.println("semester"+i);
			System.out.println("enter no of subjects in sem"+i);
			int sub;
			sub=in.nextInt();
			total.put(i,sub);
			for(int j=1;j<=sub;j++)
			{
				int grades,credits;
				System.out.println("enter credits of subject "+j);
				credits=in.nextInt();
				System.out.println("enter grade of subject "+j);
				try
				{
					grades=in.nextInt();
					if(grades>10)
					{
						j--;
						throw(new gradeexception("gradeexceed"));
						
					}
					else
					{
						obj=new Subjectlist(credits,grades);
						sems.put(u, obj);
						u++;
						tg+=credits*grades;
						cg+=credits*10;
						tcg+=credits;
					}
					
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
			}
			try
			{
				if(tcg>30)
				{
					i--;
					u=u-sub;
					throw(new creditexception("creditlimit"));
						
				}
				else
				{
					double y=((double)tg/cg)*10;
					sgpa.put(i,y);
					totalcgpa+=y;
					
				}
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
	}

}
class gradeexception extends Exception{
	
	 gradeexception(String s)
	{
		super(s);
	}
}
class creditexception extends Exception{
	creditexception(String s)
	{
		super(s);
	}
}