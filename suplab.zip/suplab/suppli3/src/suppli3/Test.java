package suppli3;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		two t2=new two();
		t2.getdata();
		t2.putdata();
		four t4=new four();
		t4.getdata();
		t4.putdata();
		mytwo mt2=new mytwo("mohit","yamaha","blue","fourstroke",154000);

	}

}
