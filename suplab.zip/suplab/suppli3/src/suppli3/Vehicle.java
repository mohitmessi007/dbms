package suppli3;

import java.util.Scanner;

public abstract class Vehicle {
	int yom;
	abstract void putdata();
	abstract void getdata();
	
}
class two extends Vehicle{
	
	String brand,egtp,color;
	int cost;
	int y=2017;
	two()
	{
		this.yom=y;
	}
	@Override
	void putdata() {
		// TODO Auto-generated method stub
		
		System.out.println("brand\n"+brand+"cost\n"+cost+"engine\n"+egtp+"color\n"+color);
	}
	@Override
	void getdata() {
		// TODO Auto-generated method stub
		
		Scanner in=new Scanner(System.in);
		brand=in.next();
		cost=in.nextInt();
		color=in.next();
		egtp=in.next();
	}
	
}
class four extends Vehicle{
	
	String brand,egtp,color;
	int cost;
	int y=2017;
	
	@Override
	void putdata() {
		// TODO Auto-generated method stub

		System.out.println("brand\n"+brand+"cost\n"+cost+"engine\n"+egtp+"color\n"+color);
		
	}
	@Override
	void getdata() {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		brand=in.next();
		cost=in.nextInt();
		color=in.next();
		egtp=in.next();
	
		
	}
	
}
class mytwo extends two{
	
	String owner;
	mytwo(String o,String b,String c,String et,int cost)
	{
		owner=o;
		super.brand=b;
		super.color=c;
		super.cost=cost;
		super.egtp=et;
	}
	
}
