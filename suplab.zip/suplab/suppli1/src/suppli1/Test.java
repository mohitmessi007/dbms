package suppli1;

import java.util.*;

public class Test {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		String name;
		int phone,accno;
		float balance;
		Scanner in=new Scanner(System.in);
		
		Account obj[]=new Account[50];
		int n;
		System.out.println("no. of emp\n");
		n=in.nextInt();
		while(true)
		{
			System.out.println("1.) Enter Details\n2.)Deposit\n3.)withdraw\n4.)Display");
			int ch=in.nextInt();
			switch(ch)
			{
			case 1:
				for(int i=1;i<=n;i++)
				{
					System.out.println("name");
					name=in.next();
					System.out.println("phoneno");
					phone=in.nextInt();
					System.out.println("Balance");
					balance=in.nextFloat();
					System.out.println("Accountno");
					accno=in.nextInt();
					obj[i]=new Account(name,phone,accno,balance);
					obj[i].display();
				}
				break;
			case 2:
				System.out.println("enter the account no. for dep");
				int k;
				k=in.nextInt();
				for(int i=1;i<=n;i++)
				{
					if(obj[i].a==k)
					{
						obj[i].deposit();
						obj[i].display();
					}
				}
				break;
			case 3:
				System.out.println("enter the account no. for with");
				int m;
				m=in.nextInt();
				for(int j=1;j<=n;j++)
				{
					if(obj[j].a==m)
					{
						obj[j].withdraw();
						obj[j].display();
					}
				}
				break;
			case 4:
				System.out.println("displaydetails of emp < 1000 balance");
				for(int c=1;c<=n;c++)
				{
					if(obj[c].bal<1000)
					{
						obj[c].display();
					}
				}
			}
		}

	}

}
