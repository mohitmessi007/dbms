package suppli1;

import java.util.*;

public class Account {
	
	String name;
	int p,a;
	float bal;
	Scanner in=new Scanner(System.in);
	
	Account(String name,int phone,int acc,float b)
	{
		this.a=acc;
		this.name=name;
		this.p=phone;
		this.bal=b;
	}
	public void deposit()
	{
		System.out.println("enter dp amt");
	    float dep;
	    dep=in.nextFloat();
	    bal+=dep;
	    System.out.println("balance is "+bal);
	}
	public void withdraw()
	{
		System.out.println("enter wh amt");
	    float with;
	    with=in.nextFloat();
	    if(with>bal)
	    	System.out.println("less money");
	    else
	       bal-=with;
	    
	    System.out.println("balance is "+bal);
	}
	public void display()
	{
		System.out.println("name:\n"+name+"accno\n"+a+"phoneno\n"+p+"balance\n"+bal);
	}
}
