package program6sj;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Swing {
	
	public static void main(String[] args) {
		JFrame frame = new JFrame("WELCOME");
		JTextField a1,a2,a3,a4,a5,b1,b2,b3,b4,b5;
		a1 = new JTextField(20);b1 = new JTextField(20);
		a2 = new JTextField(20);b2 = new JTextField(20);
		a3 = new JTextField(20);b3 = new JTextField(20);
		a4 = new JTextField(20);b4 = new JTextField(20);
		a5 = new JTextField(20);b5 = new JTextField(20);
		JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;
		l1 = new JLabel("RepNo");l6 = new JLabel("CustNo");
		l2 = new JLabel("RepName");l7 = new JLabel("CustName");
		l3 = new JLabel("State");l8 = new JLabel("State");
		l4 = new JLabel("Commission");l9 = new JLabel("CreditLimit");
		l5 = new JLabel("rate");l10 = new JLabel("RepNo");
		JButton jb1,jb2,jb3;
		jb1 = new JButton("Submit Details");
		jb2 = new JButton("Submit Details");
		jb3 = new JButton("View Details");
		JLabel represent = new JLabel("REPRESENTATIVE TABLE ENTRY");
		JLabel customer = new JLabel("CUSTOMER DETAILS");
		
		represent.setBounds(20,5,300,30);
		a1.setBounds(120, 40, 20, 20);l1.setBounds(10,40,100,20);
		a2.setBounds(120, 70, 50, 20);l2.setBounds(10,70,100,20);
		a3.setBounds(120, 100, 50, 20);l3.setBounds(10,100,100,20);
		a4.setBounds(120, 130, 50, 20);l4.setBounds(10,130,100,20);
		a5.setBounds(120, 160, 50, 20);l5.setBounds(10,160,100,20);
		jb1.setBounds(10, 190, 150, 20);
		
		customer.setBounds(20,230,300,30);
		b1.setBounds(120, 260, 50, 20);l6.setBounds(10,260,100,20);
		b2.setBounds(120, 290, 50, 20);l7.setBounds(10,290,100,20);
		b3.setBounds(120, 320, 50, 20);l8.setBounds(10,320,100,20);
		b4.setBounds(120, 350, 50, 20);l9.setBounds(10,350,100,20);
		b5.setBounds(120, 380, 50, 20);l10.setBounds(10,380,100,20);
		jb2.setBounds(10, 410, 150, 20);
		
		jb3 = new JButton("View Details for credit limit > 15000");
		jb3.setBounds(20,450,400,20);
		
		frame.setLayout(null);
		frame.setSize(600, 800);
		frame.add(a1);frame.add(a2);frame.add(a3);frame.add(a4);frame.add(a5);
		frame.add(l1);frame.add(l2);frame.add(l3);frame.add(l4);frame.add(l5);
		frame.add(represent);frame.add(jb1);
		frame.add(b1);frame.add(b2);frame.add(b3);frame.add(b4);frame.add(b5);
		frame.add(l6);frame.add(l7);frame.add(l8);frame.add(l9);frame.add(l10);
		frame.add(customer);frame.add(jb2);
		frame.add(jb3);
		frame.setVisible(true);
		
		jb1.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String sql = "insert into representative(repno,repname,state,commission,rate)values(?,?,?,?,?)";
				PreparedStatement stmt;
				try{
					Class.forName("com.mysql.jdbc.Driver");
					final Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/soni", "root", "root");
					stmt = con.prepareStatement(sql);
					stmt.setString(1, a1.getText());
					stmt.setString(2, a2.getText());
					stmt.setString(3, a3.getText());
					stmt.setString(4, a4.getText());
					stmt.setString(5, a5.getText());
					stmt.executeUpdate();
					a1.setText("");a2.setText("");a3.setText("");a4.setText("");a5.setText("");
				} catch (SQLException e) {
					e.printStackTrace();
				}catch(Exception x){
					x.printStackTrace();
				}
			};
	});
		
		jb2.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String sql = "insert into customer(custno,custname,state,creditlimit,repno)values(?,?,?,?,?)";
				PreparedStatement stmt;
				try{
					Class.forName("com.mysql.jdbc.Driver");
					final Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/soni", "root", "root");
					stmt = con.prepareStatement(sql);
					stmt.setString(1, b1.getText());
					stmt.setString(2, b2.getText());
					stmt.setString(3, b3.getText());
					stmt.setString(4, b4.getText());
					stmt.setString(5, b5.getText());
					stmt.executeUpdate();
					b1.setText("");b2.setText("");b3.setText("");b4.setText("");b5.setText("");
				} catch (SQLException e) {
					e.printStackTrace();
				}catch(Exception x){
					x.printStackTrace();
				}
			};
	});
		
		jb3.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String sql = "select representative.* from representative,customer where customer.repno = representative.repno and customer.creditlimit > 15000";
			try{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/soni", "root", "root");
				Statement s = con.createStatement();
				ResultSet rs = s.executeQuery(sql);
				output obj1 = new output(rs);
				}catch(Exception e){
				e.printStackTrace();
			}
			}
		});
	}
}

class output extends JFrame
{
	public output(ResultSet rs) throws SQLException{
		String[] head = new String[] {"RepNo","RepName","State","Commission","rate"};
		String[][] body = new String[100][5];
		int x=0;
		while(rs.next()){
			String s1 = rs.getString("repno");
			String s2 = rs.getString("repname");
			String s3 = rs.getString("state");
			String s4 = rs.getString("commission");
			String s5 = rs.getString("rate");
			body[x] = new String[] {s1,s2,s3,s4,s5};
			x++;
		}
		JTable table = new JTable(body,head);
		this.add(new JScrollPane(table));
		this.setSize(600, 600);
		this.setTitle("Representative");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
	}
}
