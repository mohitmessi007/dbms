package prog2;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String color;
		int size;
		int price;
		Scanner in=new Scanner(System.in);
		color=in.nextLine();
		size=in.nextInt();
		price=in.nextInt();
		PartyWear pw=new PartyWear("black",40,600,true,true,"NIKE");
		Pullover p1=new Pullover(color,size,price,true,true);
		FormalShirt f1=new FormalShirt(color,size,price,true,false);
		//PartyWear pw=new PartyWear("black",40,600,true,true,"NIKE");
		pw.display();
		p1.getcolor();
		p1.display();
		p1.putcolor();
	f1.getcolor();
		f1.display();
	f1.putcolor();
		
	}

}
