package prog2;

public abstract class Shirt {
	
	int size;
	int price;
	String color;
	abstract void getcolor();
	abstract void putcolor();
	
	Shirt(String color,int size,int price)
	{
		this.color=color;
		this.size=size;
		this.price=price;
	}
	
}
final class Pullover extends Shirt{
	
	boolean hashood,hasstripes;

	Pullover(String color, int size, int price,boolean hh,boolean hs) {
		super(color, size, price);
		// TODO Auto-generated constructor stub
		this.hashood=hh;
		this.hasstripes=hs;
		
	}

	@Override
	void getcolor() {
		// TODO Auto-generated method stub
		color="Blue";
		
	}

	@Override
	void putcolor() {
		// TODO Auto-generated method stub
		System.out.println("Color is"+color);
		
	}
	void display()
	{
		System.out.println("Size is"+size+"\nColor is :"+color+"Price is :"+price+"\nHasHOOD :"+hashood+"\nHasstripes :"+hasstripes);
	}
	
	
	
}
class FormalShirt extends Shirt{
	
	boolean hasfullsleeve,hasstripes;
	String color;

	FormalShirt(String color, int size, int price,boolean hfs,boolean hs) {
		super(color, size, price);
		this.hasfullsleeve=hfs;
		this.hasstripes=hs;
		this.color=color;
		//color="velvet";
		// TODO Auto-generated constructor stub
	}

	@Override
	void getcolor() {
		// TODO Auto-generated method stub
		color= "GREEN";
	}

	@Override
	void putcolor() {
		// TODO Auto-generated method stub
		System.out.println("color is :"+color);
	}
	void display()
	{
		System.out.println("Size is"+size+"\nColor is :"+color+"\nPrice is :"+price+"\nFullSleeve :"+hasfullsleeve+"\nHasstripes :"+hasstripes+"");
	}
	
}
class PartyWear extends FormalShirt{
	
	String brand;
	String c;

	PartyWear(String color, int size, int price,boolean hfs,boolean hs,String Brand) {
		super(color, size, price,hfs,hs);
		// TODO Auto-generated constructor stub
		this.brand=Brand;
		c=super.color;
		
	}
	void display()
	{
		System.out.println("Size is"+size+"\nColor is :"+c+"\nPrice is :"+price+"\nFullSleeve :"+hasfullsleeve+"\nHasstripes :"+hasstripes+"\nBrand is :"+brand);
	}
	
}

