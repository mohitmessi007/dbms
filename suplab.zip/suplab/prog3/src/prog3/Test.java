package prog3;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner in=new Scanner(System.in);
		int count=0;
		Calendar cal=Calendar.getInstance();
		
		HashMap<Integer,Phone> hmap=new HashMap<Integer,Phone>();
		ArrayList<Missed> mlist=new ArrayList<Missed>();
		hmap.put(1,new Phone("mohit","101"));
		hmap.put(2,new Phone("bagr","102"));
		hmap.put(3,new Phone("A","103"));
		hmap.put(4,new Phone("B","104"));
		hmap.put(5,new Phone("C","105"));
		hmap.put(6,new Phone("D","106"));
		hmap.put(7,new Phone("E","107"));
		
		while(true)
		{
			int ch;
			System.out.println("1.Add\n2.Log\n3.Exit");
		    ch=in.nextInt();
		    switch(ch)
		    {
		    case 1:
		    	if(count>7)
		    	{
		    		mlist.remove(0);
		    		count--;
		    	}
		    	System.out.println("meow");
		    	System.out.println("enter a miscall no.");
		    	String number;
		    	number=in.next();
		    	String caller="private";
		    	for(i=1;i<=7;i++)
		    	{
		    		
		    	}
		    	int H=cal.get(Calendar.HOUR);
		    	int M=cal.get(Calendar.MINUTE);
		    	int S=cal.get(Calendar.SECOND);
		    	String time=H+":"+M+":"+S;
		    	mlist.add(new Missed(obj.name_p,obj.phone_p,time));
		    	count++;
		    	break;
		    case 2:
		    	for(int i=0;i<mlist.size();i++)
		    	{
		    		Missed obj1=mlist.get(i);
		    		System.out.println("\n"+obj1.name+"\n"+obj1.phone+"\n"+obj1.time);
		    		System.out.println("1.Dispalynext\n2.Displaynext and delete current");
		    		int x;
		    		x=in.nextInt();
		    		switch(x)
		    		{
		    		case 1:
		    			continue;
		    		case 2:
		    			mlist.remove(i);
		    			i--;
		    			count--;
		    			continue;   			
		    		}
		    	}
		    	break;
		  
		    case 3:
		    	System.exit(0);
		    }
		}

	}

}
