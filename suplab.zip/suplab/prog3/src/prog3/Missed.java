package prog3;

public class Missed {
	
	String time,name,phone;
	Missed(String nam,String ph,String t)
	{
		name=nam;
		phone=ph;
		time=t;
	}
	
	public String toString()
	{
		return "Name :"+name+"\nPhone"+phone+"\nTime"+time;
		
	}

}
