package prog3;

public class Phone {
	
	String name_p,phone_p;
	
	Phone(String name,String p)
	{
		name_p=name;
		phone_p=p;
				
	}

}
